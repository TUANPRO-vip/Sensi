# TSX Tuner
App Android chỉnh thông số hệ thống (tốc độ con trỏ, hiện điểm chạm, tắt animation).
1. Đẩy repo lên GitHub -> tab Actions -> Build APK -> tải artifact `TSX-Tuner-apk`.
2. Cài APK, rồi chạy 1 lần trên PC:
   `adb shell pm grant com.tsx.tuner android.permission.WRITE_SECURE_SETTINGS`
