package com.tsx.tuner;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String[] ANIM = {"window_animation_scale", "transition_animation_scale", "animator_duration_scale"};
    private TextView tvBadge, tvPermDesc, tvCmd, tvDevice, tvPointer;
    private SeekBar seek;
    private Switch swTouches, swAnim;
    private boolean loading;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        tvBadge = findViewById(R.id.tvBadge); tvPermDesc = findViewById(R.id.tvPermDesc);
        tvCmd = findViewById(R.id.tvCmd); tvDevice = findViewById(R.id.tvDevice);
        tvPointer = findViewById(R.id.tvPointer); seek = findViewById(R.id.seekPointer);
        swTouches = findViewById(R.id.swTouches); swAnim = findViewById(R.id.swAnim);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                tvPointer.setText((p - 7 > 0 ? "+" : "") + (p - 7));
                if (user && !loading) putSystem("pointer_speed", p - 7);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        swTouches.setOnCheckedChangeListener((v, on) -> { if (!loading) putSystem("show_touches", on ? 1 : 0); });
        swAnim.setOnCheckedChangeListener((v, on) -> {
            if (loading) return;
            for (String k : ANIM) putGlobal(k, on ? "0" : "1.0");
        });
        findViewById(R.id.btnReset).setOnClickListener(v -> {
            putSystem("pointer_speed", 0); putSystem("show_touches", 0);
            for (String k : ANIM) putGlobal(k, "1.0");
            refresh();
            Toast.makeText(this, "Đã khôi phục mặc định", Toast.LENGTH_SHORT).show();
        });
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private boolean hasSecure() {
        return checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED;
    }

    private void refresh() {
        loading = true;
        boolean ok = hasSecure();
        tvBadge.setText(ok ? "● ONLINE" : "● CHƯA CẤP");
        tvBadge.setTextColor(ok ? 0xFF22E36B : 0xFFFF4D6A);
        tvBadge.setBackgroundResource(ok ? R.drawable.bg_badge : R.drawable.bg_badge_off);
        tvPermDesc.setText(ok ? "Đã cấp quyền, sẵn sàng sử dụng" : "Cần cấp quyền 1 lần qua ADB (từ PC):");
        tvCmd.setText(ok ? "" : "adb shell pm grant " + getPackageName() + " android.permission.WRITE_SECURE_SETTINGS");
        tvDevice.setText(Build.MANUFACTURER + " " + Build.MODEL + " (Android " + Build.VERSION.RELEASE + ")");
        try {
            int p = Settings.System.getInt(getContentResolver(), "pointer_speed", 0);
            seek.setProgress(Math.max(-7, Math.min(7, p)) + 7);
            tvPointer.setText((p > 0 ? "+" : "") + p);
            swTouches.setChecked(Settings.System.getInt(getContentResolver(), "show_touches", 0) == 1);
            swAnim.setChecked(Settings.Global.getFloat(getContentResolver(), ANIM[0], 1f) == 0f);
        } catch (Exception ignored) {}
        loading = false;
    }

    private void putSystem(String key, int val) {
        try {
            if (!hasSecure() && !Settings.System.canWrite(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
                return;
            }
            Settings.System.putInt(getContentResolver(), key, val);
        } catch (Exception e) { fail(); }
    }

    private void putGlobal(String key, String val) {
        try {
            if (!hasSecure()) { fail(); return; }
            Settings.Global.putString(getContentResolver(), key, val);
        } catch (Exception e) { fail(); }
    }

    private void fail() {
        Toast.makeText(this, "Chưa có quyền. Hãy chạy lệnh ADB hiển thị ở trên.", Toast.LENGTH_LONG).show();
        refresh();
    }
}
